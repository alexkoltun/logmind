#!/bin/sh
echo $LD_LIBRARY_PATH | egrep "/usr/local/logmind/rubystack/common" > /dev/null
if [ $? -ne 0 ] ; then
PATH="/usr/local/logmind/rubystack/memcached/bin:/usr/local/logmind/rubystack/perl/bin:/usr/local/logmind/rubystack/git/bin:/usr/local/logmind/rubystack/nginx/sbin:/usr/local/logmind/rubystack/sphinx/bin:/usr/local/logmind/rubystack/sqlite/bin:/usr/local/logmind/rubystack/mysql/bin:/usr/local/logmind/rubystack/apache2/bin:/usr/local/logmind/rubystack/subversion/bin:/usr/local/logmind/rubystack/ruby/bin:/usr/local/logmind/rubystack/common/bin:$PATH"
export PATH
LD_LIBRARY_PATH="/usr/local/logmind/rubystack/ruby/lib/ruby/gems/1.9.1/gems/passenger-3.9.1.beta/lib:/usr/local/logmind/rubystack/memcached/lib:/usr/local/logmind/rubystack/perl/lib:/usr/local/logmind/rubystack/perl/lib/5.8.8/x86_64-linux/CORE:/usr/local/logmind/rubystack/git/lib:/usr/local/logmind/rubystack/nginx/lib:/usr/local/logmind/rubystack/sqlite/lib:/usr/local/logmind/rubystack/mysql/lib:/usr/local/logmind/rubystack/apache2/lib:/usr/local/logmind/rubystack/subversion/lib:/usr/local/logmind/rubystack/ruby/lib:/usr/local/logmind/rubystack/common/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH
fi

##### MEMCACHED ENV #####
		
      ##### PERL ENV #####
PERL5LIB="/usr/local/logmind/rubystack/perl/lib/5.8.8:/usr/local/logmind/rubystack/perl/lib/site_perl/5.8.8:/usr/local/logmind/rubystack/perl/lib/5.8.8/x86_64-linux:/usr/local/logmind/rubystack/perl/lib/site_perl/5.8.8/x86_64-linux"
export PERL5LIB
##### GIT ENV #####
PERL5LIB="/usr/local/logmind/rubystack/git/lib/site_perl/5.8.8:$PERL5LIB"			
export PERL5LIB
GITPERLLIB="/usr/local/logmind/rubystack/git/lib/site_perl/5.8.8"
export GITPERLLIB
GIT_EXEC_PATH=/usr/local/logmind/rubystack/git/libexec/git-core/
export GIT_EXEC_PATH
GIT_TEMPLATE_DIR=/usr/local/logmind/rubystack/git/share/git-core/templates
export GIT_TEMPLATE_DIR
GIT_SSL_CAINFO=/usr/local/logmind/rubystack/common/openssl/certs/curl-ca-bundle.crt
export GIT_SSL_CAINFO

##### NGINX ENV #####
			
LDAPCONF=/usr/local/logmind/rubystack/common/etc/openldap/ldap.conf
export LDAPCONF
##### SQLITE ENV #####
			
##### IMAGEMAGICK ENV #####
MAGICK_HOME="/usr/local/logmind/rubystack/common"
export MAGICK_HOME

MAGICK_CONFIGURE_PATH="/usr/local/logmind/rubystack/common/lib/ImageMagick-6.7.5/config:/usr/local/logmind/rubystack/common/"
export MAGICK_CONFIGURE_PATH

MAGICK_CODER_MODULE_PATH="/usr/local/logmind/rubystack/common/lib/ImageMagick-6.7.5/modules-Q16/coders"
export MAGICK_CODER_MODULE_PATH

GS_LIB="/usr/local/logmind/rubystack/common/share/ghostscript/fonts"
export GS_LIB
##### MYSQL ENV #####

##### APACHE ENV #####

##### SUBVERSION ENV #####
			
##### RUBY ENV #####
GEM_HOME="/usr/local/logmind/rubystack/ruby/lib/ruby/gems/1.9.1"
GEM_PATH="/usr/local/logmind/rubystack/ruby/lib/ruby/gems/1.9.1"
RUBY_HOME="/usr/local/logmind/rubystack/ruby"
RUBYLIB="/usr/local/logmind/rubystack/ruby/lib/ruby/site_ruby/1.9.1:/usr/local/logmind/rubystack/ruby/lib/ruby/site_ruby/1.9.1/x86_64-linux:/usr/local/logmind/rubystack/ruby/lib/ruby/site_ruby/:/usr/local/logmind/rubystack/ruby/lib/ruby/vendor_ruby/1.9.1:/usr/local/logmind/rubystack/ruby/lib/ruby/vendor_ruby/1.9.1/x86_64-linux:/usr/local/logmind/rubystack/ruby/lib/ruby/vendor_ruby/:/usr/local/logmind/rubystack/ruby/lib/ruby/1.9.1:/usr/local/logmind/rubystack/ruby/lib/ruby/1.9.1/x86_64-linux:/usr/local/logmind/rubystack/ruby/lib/ruby/:/usr/local/logmind/rubystack/ruby/lib"
RUBYOPT=rubygems
BUNDLE_CONFIG="/usr/local/logmind/rubystack/ruby/.bundler/config"
export GEM_HOME
export GEM_PATH
export RUBY_HOME
export RUBYLIB
export RUBYOPT
export BUNDLE_CONFIG
##### CURL ENV #####
CURL_CA_BUNDLE=/usr/local/logmind/rubystack/common/openssl/certs/curl-ca-bundle.crt
export CURL_CA_BUNDLE
##### SSL ENV #####
SSL_CERT_FILE=/usr/local/logmind/rubystack/common/openssl/certs/curl-ca-bundle.crt
export SSL_CERT_FILE


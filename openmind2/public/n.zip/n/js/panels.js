/*jshint globalstrict:true */
/*global angular:true */
'use strict';

angular.module('openmind.panels', [])

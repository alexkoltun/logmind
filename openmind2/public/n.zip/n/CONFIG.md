Configuration
=============

config.js
---------

1. Update elasticsearch URL to 'your-openmind-url/napi/es/'